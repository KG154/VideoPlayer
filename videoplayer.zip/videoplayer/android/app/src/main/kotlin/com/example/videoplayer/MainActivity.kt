package com.example.videoplayer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
